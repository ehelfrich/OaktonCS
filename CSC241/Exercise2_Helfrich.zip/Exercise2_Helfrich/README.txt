*INFORMATION*
For myself and anyone else

Same program as lab2 with the modifications to report amount of attempts per question

Since the src folder is the Exercise2_Helfrich folder after compiling files in lab2
exec with command "java lab2.TriviaConsole"
