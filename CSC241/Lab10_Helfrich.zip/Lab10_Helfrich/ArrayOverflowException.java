
public class ArrayOverflowException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ArrayOverflowException() {
		super();
	}

	public ArrayOverflowException(String e) {
		super(e);
	}
}
