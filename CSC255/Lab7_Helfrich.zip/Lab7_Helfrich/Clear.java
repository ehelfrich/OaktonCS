public class Clear {

	public static void clearScreen() {
		System.out.print("\033[2J\033[;H");
	}

}
