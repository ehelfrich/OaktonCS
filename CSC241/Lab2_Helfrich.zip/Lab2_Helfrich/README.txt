*INFORMATION*
For myself and anyone else

The Lab2 question #57 is located in the package lab2.
It does contain the modifications needed for exercise #2, but it has not changed the core of lab2

Since the src folder is the Lab2_Helfrich folder after compiling files in lab2
exec with command "java lab2.TriviaConsole"

The questions for the book are located in the .docx file
